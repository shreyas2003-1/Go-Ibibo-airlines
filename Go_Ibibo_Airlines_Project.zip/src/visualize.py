import matplotlib.pyplot as plt

def plot_histogram(data, column):
    plt.hist(data[column], bins=20)
    plt.show()
