import pandas as pd

def preprocess_data(filepath):
    df = pd.read_csv(filepath)
    # Data preprocessing steps here
    return df

if __name__ == '__main__':
    df = preprocess_data('data/goibibo_flights_data.csv')
    print(df.head())
