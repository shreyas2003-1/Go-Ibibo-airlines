# Go Ibibo Airlines - Flight Price Prediction

## Project Overview
This project analyzes airline flight data to predict flight prices. It includes:
- Data cleaning and preprocessing
- Exploratory Data Analysis (EDA)
- Feature engineering
- Machine learning model training (SVM, Naive Bayes)
- Data visualization

## Project Structure
```
Go_Ibibo_Airlines_Project/
│── README.md              # Project description
│── requirements.txt       # Dependencies
│── .gitignore             # Ignore unnecessary files
│── Go_Ibibo_AirLines.ipynb # Jupyter Notebook
│── workflow.png           # Workflow diagram
│── er_diagram.png         # ER diagram
│── data/
│   └── goibibo_flights_data.csv (placeholder)
│── src/
│   ├── preprocess.py      # Data cleaning functions
│   ├── train_model.py     # Model training script
│   ├── visualize.py       # Visualization functions
└── notebooks/
    └── exploratory_analysis.ipynb  # Additional EDA
```

## Setup Instructions
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run preprocessing script:
   ```bash
   python src/preprocess.py
   ```
3. Train the model:
   ```bash
   python src/train_model.py
   ```

## Dependencies
- pandas
- numpy
- matplotlib
- seaborn
- scikit-learn
- plotly
